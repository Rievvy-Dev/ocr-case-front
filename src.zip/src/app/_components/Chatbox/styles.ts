import styled from "styled-components";

export const ChatboxContainer = styled.div`
  width: 100%;
  max-width: 600px;
  height: 400px;
  background: white;
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const Message = styled.div<{ isUser: boolean }>`
  align-self: ${(props) => (props.isUser ? "flex-end" : "flex-start")};
  background: ${(props) => (props.isUser ? "#007bff" : "#ddd")};
  color: ${(props) => (props.isUser ? "white" : "black")};
  padding: 10px;
  border-radius: 10px;
  max-width: 70%;
  word-wrap: break-word;
`;

export const InputContainer = styled.div`
  display: flex;
  width: 100%;
  margin-top: 10px;
`;

export const ChatInput = styled.input`
  flex: 1;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
`;

export const SendButton = styled.button`
  background: #007bff;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  margin-left: 5px;
  cursor: pointer;

  &:hover {
    background: #0056b3;
  }
`;
