"use client";

import { useEffect, useState } from "react";
import SubmitButton from "../SubmitButton";
import Dropzone from "../Dropzone";
import * as S from "./styles";
import { uploadFile, fetchPdfById } from "@/services/api";
import PDFPreview from "../PDFPreview";

interface DropboxProps {
  pdfId: string | null;
}

const Dropbox = ({ pdfId }: DropboxProps) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>("");

  useEffect(() => {
    if (pdfId) {
      loadPdf(pdfId);
    }
  }, [pdfId]);

  const loadPdf = async (id: string) => {
    try {
      const url = await fetchPdfById(id);
      setPdfUrl(url);
    } catch (error) {
      console.error("Erro ao carregar PDF:", error);
    }
  };

  const handleFileSelected = (file: File | null) => {
    if (file) {
      if (file.type !== "application/pdf") {
        setErrorMessage("Apenas arquivos PDF são permitidos.");
        setSelectedFile(null);
        return;
      }

      if (file.size > 50 * 1024 * 1024) {
        setErrorMessage("O arquivo deve ter no máximo 50MB.");
        setSelectedFile(null);
        return;
      }

      setErrorMessage("");
      setSelectedFile(file);
      setPdfUrl(null);
    } else {
      setErrorMessage("");
      setSelectedFile(null);
    }
  };

  const handleSubmit = async () => {
    if (!selectedFile) {
      alert("Por favor, selecione um arquivo antes de enviar.");
      return;
    }

    try {
      await uploadFile(selectedFile);
      alert("Arquivo enviado com sucesso!");
    } catch {
      alert("Erro ao enviar o arquivo.");
    }
  };

  return (
    <S.ComponentContainer>
      {!selectedFile && !pdfUrl && (
        <S.Title>Arraste seu documento para o dropbox abaixo:</S.Title>
      )}

      {!selectedFile && pdfUrl ? (
        <S.PDFContainer>
          <S.PDFWrapper>
            <iframe src={pdfUrl} title="PDF Viewer" width="100%" height="500px" />
          </S.PDFWrapper>
        </S.PDFContainer>
      ) : !selectedFile ? (
        <Dropzone onFileSelected={handleFileSelected} />
      ) : (
        <S.PDFContainer>
          <S.PDFWrapper>
            <PDFPreview file={selectedFile} />
          </S.PDFWrapper>
        </S.PDFContainer>
      )}

      {errorMessage && <S.ErrorMessage>{errorMessage}</S.ErrorMessage>}

      <S.ButtonContainer>
        <SubmitButton
          type="button"
          onClick={handleSubmit}
          disabled={!selectedFile}
        >
          Analisar
        </SubmitButton>
      </S.ButtonContainer>
    </S.ComponentContainer>
  );
};

export default Dropbox;
